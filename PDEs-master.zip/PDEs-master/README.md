# PDEs

pipelines for PDE paper

create ./input/genomes to run on desired .fasta files 
