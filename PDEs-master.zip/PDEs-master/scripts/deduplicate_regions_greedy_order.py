from Bio import SeqIO
from Bio import SeqRecord
import glob
import pandas as pd
import re
import os

def get_all_regions():
    all_regions = []
    for dir in snakemake.input.in_dirs:
        paths = glob.glob(os.path.join(dir, "*.fasta"))
        for path in paths:
            with open(path, "r") as f:
                rec = list(SeqIO.parse(f, "fasta"))[0]
                m = re.match("(.*)_start=(\d+\.0)_stop=(\d+\.0)", rec.id)
                contig, start, stop = m.groups()
                start = int(float(start))
                stop = int(float(stop))
                all_regions.append({"path":os.path.basename(path), "contig": contig, "start": start, "stop":stop})
    return all_regions

def make_new_canonical_region(region, region_is_member_of, deduped_groupings):
    if region["contig"] not in deduped_groupings:
        deduped_groupings[region["contig"]] = {}
    deduped_groupings[region["contig"]][region_is_member_of] = {
                "canonical_id":region["path"],
                "canonical_start":region["start"],
                "canonical_stop":region["stop"],
                "child_regions":[region]}
    return deduped_groupings

def is_same_region(region, aggregated_region_details):
    min_start = min(aggregated_region_details["canonical_start"], region["start"])
    max_start = max(aggregated_region_details["canonical_start"], region["start"])
    min_stop = min(aggregated_region_details["canonical_stop"], region["stop"])
    max_stop = max(aggregated_region_details["canonical_stop"], region["stop"])
    has_overlap = max_start < min_stop
    is_similar_length = (min_stop - max_start)/(max_stop - min_start) >= snakemake.params.pct_length_similar
    return has_overlap and is_similar_length


def update_canonical_region(region, region_is_member_of, deduped_groupings):
    new_record = {"canonical_start":region["start"] if deduped_groupings[region["contig"]][region_is_member_of]["canonical_start"] > region["start"] else deduped_groupings[region["contig"]][region_is_member_of]["canonical_start"],
                "canonical_stop":region["stop"] if deduped_groupings[region["contig"]][region_is_member_of]["canonical_stop"] < region["stop"] else deduped_groupings[region["contig"]][region_is_member_of]["canonical_stop"],
                "child_regions":[region] + deduped_groupings[region["contig"]][region_is_member_of]["child_regions"]}
    deduped_groupings[region["contig"]][region_is_member_of] = new_record
    return deduped_groupings

def deduplicate_regions(all_regions):
    deduped_groupings = {}
    for region in all_regions:
        if region["contig"] not in deduped_groupings:
            deduped_groupings = make_new_canonical_region(region, 0, deduped_groupings)
            continue
        else:
            region_is_member_of = max(deduped_groupings[region["contig"]].keys()) + 1
            for aggregated_region_id, aggregated_region_details in deduped_groupings[region["contig"]].items():
                if is_same_region(region, aggregated_region_details):
                    region_is_member_of = aggregated_region_id
                    break
            if region_is_member_of in deduped_groupings[region["contig"]].keys():
                deduped_groupings = update_canonical_region(region, region_is_member_of, deduped_groupings)
            else:
                deduped_groupings = make_new_canonical_region(region, region_is_member_of, deduped_groupings)
    return deduped_groupings

def flatten_groupings(deduped_groupings):
    flattened = []
    for contig, regions in deduped_groupings.items():
        for _, region in regions.items():
            record = {"contig": contig, "canonical_start":region["canonical_start"], "canonical_stop":region["canonical_stop"], "child_regions":region["child_regions"]}
            flattened.append(record)
    flattened = sorted(flattened, key = lambda v: (v["contig"], v["canonical_start"]))
    for i,v in enumerate(flattened):
        v["id"] = i
    return flattened

def write_canonical_fastas(flattened_groupings):
    with open(snakemake.input.genome, "r") as f:
        contig_records = list(SeqIO.parse(f, "fasta"))
    seqdict = {rec.id:rec for rec in contig_records}
    for region in flattened_groupings:
        canonical_record = SeqRecord.SeqRecord(id="{}_region_{:0>3d}".format(snakemake.wildcards.strain, region["id"]), seq=seqdict[region["contig"]].seq[region["canonical_start"]:region["canonical_stop"]], description = "")
        with open(os.path.join(snakemake.output.out_dir, "{}_region_{:0>3d}.fasta".format(snakemake.wildcards.strain, region["id"])), "w") as f:
            SeqIO.write(canonical_record, f, "fasta")

def write_region_table(flattened_groupings):
    rows = [{"strain": snakemake.wildcards.strain,
         "contig": child["contig"],
         "region_id": region["id"],
         "member_region": child["path"],
         "member_start": child["start"],
         "member_stop": child["stop"],
         "canonical_start": region["canonical_start"],
         "canonical_stop": region["canonical_stop"]}
         for region in flattened_groupings for child in region["child_regions"]]
    pd.DataFrame(rows).to_csv(snakemake.output.csv, index=False)
    pd.DataFrame(rows)[["strain","contig","region_id", "canonical_start", "canonical_stop"]].drop_duplicates().to_csv(snakemake.output.summary, index=False)

def write_summary_table(flattened_groupings):
    rows = [{"strain": snakemake.wildcards.strain,
         "contig": child["contig"],
         "region_id": region["id"],
         "member_region": child["path"],
         "member_start": child["start"],
         "member_stop": child["stop"],
         "canonical_start": region["canonical_start"],
         "canonical_stop": region["canonical_stop"]}
         for region in flattened_groupings for child in region["child_regions"]]
    pd.DataFrame(rows).to_csv(snakemake.output.csv, index=False)

def main():
    all_regions = get_all_regions()
    deduped_groupings = deduplicate_regions(all_regions)
    #smooshed = smoosh_regions(deduped_groupings)
    flattened_groupings = flatten_groupings(deduped_groupings)
    os.makedirs(snakemake.output.out_dir, exist_ok=True)
    write_canonical_fastas(flattened_groupings)
    write_region_table(flattened_groupings)

if __name__ == '__main__':
    main()
