import Bio
from Bio import SeqIO
from Bio import SeqRecord
import numpy as np
from multiprocessing import Pool

kmers = snakemake.input.unique_kmers
genome = snakemake.input.genome

def get_matches(kmer, genome):
    hashMatches = {}
    reverse_kmer = str(Bio.Seq.Seq(kmer).reverse_complement())
    for contig in genome:
        hashMatches[contig.id] = set()
        contig_str =str(contig.seq).lower()
        for k in [kmer, reverse_kmer]:
            start_position = 0
            new_match = 0
            while new_match != -1:
                new_match = contig_str.find(k, start_position)
                start_position = new_match +1
                if new_match != -1:
                    hashMatches[contig.id].add(new_match)
    return hashMatches

def merge_matches(matchList):
    hashMergedMatches = {}
    for matchDict in matchList:
        for contig, matches in matchDict.items():
            if contig in hashMergedMatches:
                hashMergedMatches[contig] = hashMergedMatches[contig].union(matches)
            else:
                hashMergedMatches[contig] = set()
                hashMergedMatches[contig] = hashMergedMatches[contig].union(matches)
    return hashMergedMatches

def get_regions(merged_matches, genome, max_gap_in_region = 3000, min_region_length = 1000):
   for contig_name, matches in merged_matches.items():
       contig = [rec for rec in genome if rec.id==contig_name][0]
       sorted_matches = np.sort(np.append(np.array(list(matches)), np.array([-np.inf,np.inf])))
       start_stop_indices = np.where(np.diff(np.diff(sorted_matches) < max_gap_in_region))[0] + 1
       start_stop_array = sorted_matches[start_stop_indices].reshape(-1,2)
       length_filtered = start_stop_array[start_stop_array[:,1]-start_stop_array[:,0] > min_region_length]
       #print(start_stop_array)
       for start, stop in length_filtered:
           yield SeqRecord.SeqRecord(id = "{}_start={}_stop={}".format(contig_name, start, stop), seq=contig.seq[int(start):int(stop)], description='')

with open(genome, "r") as f:
    contigs = list(SeqIO.parse(f, "fasta"))

matchList = []
with open(kmers, "r") as f:
    kmerList = f.readlines()
    kmerList = [k.strip().lower() for k in kmerList]

with Pool(processes=8) as pool:
    matchList = pool.starmap(get_matches, [(k, contigs) for k in kmerList])

hashMergedMatches = merge_matches(matchList)

with open(snakemake.output.unique_regions, "w") as f:
    SeqIO.write(get_regions(hashMergedMatches, contigs), f, "fasta")
