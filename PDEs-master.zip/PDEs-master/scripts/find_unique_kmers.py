from Bio import SeqIO 

kmers_1 = snakemake.input.kmers_1
kmers_2 = snakemake.input.kmers_2

def find_unique_kmers(kmers_1, kmers_2):
    with open(kmers_1, "r") as f: 
        records_1 = SeqIO.parse(f, "fasta")
        kmers_1 = set([str(rec.seq) for rec in records_1])
    with open(kmers_2, "r") as f: 
        records_2 = SeqIO.parse(f, "fasta")
        kmers_2 = set([str(rec.seq) for rec in records_2])
    unique_kmers_1 = kmers_1.difference(kmers_2)
    unique_kmers_2 = kmers_2.difference(kmers_1)
    return (unique_kmers_1, unique_kmers_2)

unique_kmers_1, unique_kmers_2 = find_unique_kmers(kmers_1, kmers_2)

with open(snakemake.output.unique_kmers_1, "w") as f: 
    for kmer in unique_kmers_1: 
        f.write(kmer + "\n")

with open(snakemake.output.unique_kmers_2, "w") as f: 
    for kmer in unique_kmers_2: 
        f.write(kmer + "\n")

