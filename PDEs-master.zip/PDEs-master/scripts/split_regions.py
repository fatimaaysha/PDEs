from Bio import SeqIO
import os

os.makedirs(snakemake.output.out_dir, exist_ok=True)

with open(snakemake.input.fasta, "r") as f:
    for i, rec in enumerate(SeqIO.parse(f, "fasta")):
        filename = "{}_minus_{}_region_{}.fasta".format(snakemake.wildcards.strain1, snakemake.wildcards.strain2, i)
        with open(os.path.join(snakemake.output.out_dir, filename), "w") as f:
            SeqIO.write(rec, f, "fasta")
