library(tidyverse)
library(igraph)

df <- read_tsv(snakemake@input[["mash_results"]], col_names = c("x", "y","distance", "p", "kmer_ratio"))

region_df <- snakemake@input[["region_tables"]] %>%
  map_dfr(read_csv)

mash_edges <- df %>%
  mutate(from = str_sub(x, 28,-7), to = str_sub(y, 28, -7)) %>%
  mutate(weight = 1 - distance) %>%
  select(from, to, weight)

colors <- tribble(~strain, ~color,
  "10N26149F8","orange",
  "10N26151A9","orange",
  "10N26155C8","orange",
  "10N28652E12","orange",
  "10N28654A11","purple",
  "10N28654A1","purple",
  "10N28654A6","purple",
  "10N28654A8","purple",
  "10N28654B1","purple",
  "10N28654B4","purple",
  "10N28654B8","purple",
  "10N28654E12","purple",
  "10N28654E1","purple",
  "10N28654E7","purple",
  "10N28654F6","purple",
  "10N28654F7","purple",
  "10N28654F8","purple",
  "10N28655A1","purple",
  "10N28655E1","purple"
)

orange_strains <- colors %>% filter(color=="orange") %>% pull(strain)
purple_strains <- colors %>% filter(color=="purple") %>% pull(strain)


region_vertices <- region_df %>%
  left_join(colors) %>%
  mutate(region = paste0(strain, "_region_", str_pad(region_id, 3, pad="0"))) %>%
  select(region, contig, canonical_start, canonical_stop, color) %>%
  mutate(length=canonical_stop - canonical_start) %>%
  select(id=region,size=length,color, canonical_start, canonical_stop) %>%
  mutate(label=id) %>%
  filter(size > snakemake@params[["min_length_of_region"]]) %>%
  distinct()

size_filtered_mash_edges <- mash_edges %>% filter(from %in% region_vertices$id, to %in% region_vertices$id)

graph <- graph_from_data_frame(size_filtered_mash_edges, vertices=region_vertices, directed=FALSE)
subgraphs <- clusters(subgraph.edges(graph, E(graph)[E(graph)$weight>snakemake@params[["min_jaccard_similarity"]]], del=F))

get_sequence <- function(region_id) {
  path <- paste0("temp/all_canonical_regions/",region_id,".fasta")
  str_c(str_split(read_file(path), "\n")[[1]][-1], collapse="")
}

tidy_subgraphs <- tibble(region=names(subgraphs$membership), subgraph_id=subgraphs$membership) %>%
  mutate(strain=str_sub(region, 1, -12)) %>%
  left_join(region_vertices, by=c("region" = "id")) %>%
  mutate(sequence = map_chr(region, get_sequence)) %>%
  mutate(start_seq = str_sub(sequence, 0,100), end_seq = str_sub(sequence, -100, -1)) %>%
  select(-sequence)

tidy_subgraphs %>%
  mutate(id = str_pad(subgraph_id, 3, pad="0")) %>%
  group_by(id) %>%
  select(subgraph_id, strain, contig, length=size, start=canonical_start, stop=canonical_stop, start_seq, stop_seq) %>%
  arrange(strain, contig, start) %>%
  nest %>%
  pwalk(~write.csv(..2, file = paste0("output/subgraph_tables/subgraph_", ..1, '.csv')))
