library(tidyverse)

df = read_tsv(snakemake@input[["mash_results"]])
